<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    if (empty($username) || empty($password)) {
        echo "Username and password are required.";
        exit;
    }

    if (!file_exists('users.txt')) {
        echo "User data file is missing.";
        exit;
    }

    $file = fopen('users.txt', 'r');
    $authenticated = false;

    while (($line = fgets($file)) !== false) {
        list($stored_username, $stored_hashed_password) = explode(':', trim($line));
        if ($stored_username === $username && password_verify($password, $stored_hashed_password)) {
            $authenticated = true;
            break;
        }
    }
    fclose($file);

    if ($authenticated) {
        echo "";
    } else {
        echo "Invalid credentials.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Exo+2:ital,wght@0,100..900;1,100..900&family=Jaro:opsz@6..72&family=Open+Sans:ital,wght@0,300..800;1,300..800&family=Russo+One&family=Sofia+Sans:ital,wght@0,1..1000;1,1..1000&family=Tilt+Warp&display=swap" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="sitestyle.css" media="screen" />
    <script src="script.js"></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Как да уча</title>
    
    <nav id="nav">

        <a href="index.html">


            <img id="logo" src="Учи лесно (11).png" style="height: 130px;position: relative;float: left;">

        </a>

        <table id="links" style="font-size: 30px;position: relative;top: 18px;">

            <tr style="padding: 10px;">

                <td style="padding-right: 350px;">

                </td>

                <td style="padding: 10px;">

                    <a style="position: relative;" href>

                        <p id="home">
                            Начало
                        </p>
                        <img id="homeIcon" style="height: 40px;display: none;padding-right: 50px;position: relative;top: -34px;" src="home icon.png">

                    </a>

                </td>

                <td style="padding: 10px;">

                    <a style="position: relative;" href="aboutUs.html">

                        <p id="aboutUs">
                            За нас
                        </p>
                        <img id="aboutUsIcon" style="height: 40px;display: none;padding-right: 50px;position: relative;top: -34px;" src="aboutUs icon.png">

                    </a>

                </td>
                
                <td style="padding: 10px;">

                    <a style="position: relative;" href>

                        <p id="contacts">
                            Контакти
                        </p>
                        <img id="contactsIcon" style="height: 40px;display: none;padding-right: 50px;position: relative;top: -34px;" src="contacts icon.png">

                    </a>

                </td>

                <td style="padding-left: 10px;">

                    <a style="position: relative;" href>

                        <p id="socials">
                            Социални мрежи
                        </p>
                        <img id="socialsIcon" style="height: 40px;display: none;padding-right: 50px;position: relative;top: -34px;" src="socials icon.png">

                    </a>

                </td>

                <td style="padding: 10px;position: relative;right: -500px;">

                    <a id="loginbutton" class="navlogbutton" href>

                        <p>

                            Вход

                        </p>

                                                
                    </a>

                </td>  

                    <td style="padding: 10px;position: relative;right: -350px;display: none;">

                        <a href="register.html"> 

                            <section id="registerbutton" class="navregbutton">

                                <p>
    
                                    Регистрация

                                </p>
    
                            </section>
                        </a>
                </td>

            </tr>

        </table>

    </nav>

</head>
<body style="background-color: rgb(236, 224, 209);">

<a href="upcoming.html">
<section style="background-image: url(predstoi.png);background-color: rgb(76, 224, 121);height: 300px;background-repeat: no-repeat;background-position:right;text-align: center;background-size: 370px;background-position-x: 1500px;background-position-y: 14px;">
        
    <br><br><br><br><br><br>        
    <br><br>
    
    



    <h1>
        Предстоящи:
    </h1>

    <p>
        Няма предстояща работа.
        Почини си!
    </p>

</a>

</section>
<br><br>

    <section style="text-align: center;">

        <table style="margin: auto;background-color: rgb(172, 218, 255);" cellspacing="50px">

            <tr style="background-color: rgb(118, 182, 241);">

                <td style="border-radius: 15px;height: 75px;">

                    <h1>

                        Контролни

                    </h1>

                </td>

                <td style="border-radius: 15px;">

                    <h1>

                        Календар

                    </h1>

                </td>

                <td style="border-radius: 15px;">

                    <h1>

                        Как да уча?

                    </h1>

                </td>

            </tr>    

            <tr>
                
                <td style="background-color: rgb(230, 68, 68);height: 400px;width: 400px;border-radius: 15px;">

                    <img style="height: 300px;" src="kontrolni.png">
                   
                </td>

                <td style="background-color: rgb(68, 125, 230);height: 400px;width: 400px;border-radius: 15px;">

                    <a href="calendar.html">

                        <img style="height: 300px;" src="calendar.png">

                    </a>
                    
                </td>

                <td style="background-color: rgb(230, 219, 68);height: 400px;width: 400px;border-radius: 15px;">

                    <img style="height: 300px;" src="how2learn.png">
                    
                </td>

            </tr>

        </table>

    </section>

    <br><br>

    <section style="width: 100%;background-color: rgb(112, 170, 224);height: 500px;display: flex;align-items:center;">

        <p style="margin-left: 700px;margin-right: 700px;font-size: 40px;">

            "Странното нещо за скуката е, че винаги възниква, когато човек, всъщност има доста неща за правене." - неизвестен автор

        </p>
        


    </section>

    <footer>

        <table>

            <tr>

                <td>

                    <img style="height: 100px;" src="Учи лесно (8).png">

                </td>

                <td>

                    <h1 style="font-size: 60px;padding-left: 20px;">

                        Учи лесно

                    </h1>

                </td>

            </tr>

        </table>

        <hr>

        <br>

        <table>

            <tr style="align-items: flex-start;display: flex;">

                <td>

                    <ul>

                        <li>

                            <p style="font-size: 25px;font-weight: 700;">

                                За нас
                            </p>

                        </li>

                        <li>
                            
                            <p>

                                Учи лесно™️

                            </p>

                        </li>

                        <li>
                            
                            <p>

                                Отборът ни

                            </p>

                        </li>

                        <li>
                            
                            <p>

                                Правила и условия

                            </p>

                        </li>

                    </ul>

                </td>

                <td>

                    <ul>

                        <li>

                            <p style="font-size: 25px;font-weight: 700;">

                                Свържете се
                            </p>

                        </li>

                        <li>
                            
                            <p>

                                <img src="socials icon.png">

                            </p>

                        </li>

                        <li>
                            
                            <p>

                                <img src="aaa.png">

                            </p>

                        </li>

                        <li>
                            
                            <p>

                                <img src="X_logo_2023_(white).png">

                            </p>

                        </li>

                    </ul>

                </td>

                <td>

                    <ul>

                        <li>

                            <p style="font-size: 25px;font-weight: 700;">

                                Навигация
                            </p>

                        </li>

                        <li>
                            
                            <p>

                                <a href="">

                                    Начало

                                </a>

                            </p>

                        </li>

                    </ul>
                    
                </td>

            </tr>

        </table>

        <br>

        <hr>


    </footer>

</body>
</html>