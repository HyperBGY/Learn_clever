<!DOCTYPE html>
<html lang="en">
<head>
<meta name="viewport" content="width=device-width">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Exo+2:ital,wght@0,100..900;1,100..900&family=Jaro:opsz@6..72&family=Open+Sans:ital,wght@0,300..800;1,300..800&family=Russo+One&family=Sofia+Sans:ital,wght@0,1..1000;1,1..1000&family=Tilt+Warp&display=swap" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="sitestyle.css" media="screen" />
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>скибиди</title>
    <script src="homescript.js"></script>

    <div>
    <nav id="nav">

        <div style="margin-right: 1.042vw;margin-left: 0.521vw;margin-top:0.521vw;">

        <a href="index.html">

            <img id="logo" src="Учи лесно (11).png" style="height: 6.771vw;position: relative;top:-0.781vw;float: left;">



        </a>

        <div class="dropdown">


            <img id="menuicon" class="dropbtn" src="menuicon.png">
            <div id="menu-content" class="dropdown-content">
              <a href="1page.html">Настройки</a>
              <a href="2page.html">Свържете се</a>
              <a href="3page.html">Скинове</a>
            </div>
          </div>
        </div>

        <table id="links" style="margin-left: 35.417vw;margin-right:35.417vw;position: relative ; ">

            <tr>

                <td style="padding-right: 0.521vw;">

                    <a href="home.html">

                        <p id="home">
                            Начало
                        </p>
                        <img id="homeIcon" style="height: 2.083vw;display: none;padding-right: 2.604vw;;" src="home icon.png">

                    </a>

                </td>

                <td style="padding: 0.521vw;">

                    <a href="aboutUs.html">

                        <p id="aboutUs">
                            Статиски
                        </p>
                        <img id="aboutUsIcon" style="height: 2.083vw;display: none;padding-right: 2.604vw;;" src="aboutUs icon.png">

                    </a>

                </td>
                
                <td style="padding: 0.521vw;">

                    <a style="" href>

                        <p id="contacts">
                            Награди
                        </p>
                        <img id="contactsIcon" style="height: 2.083vw;display: none;padding-right: 2.604vw;;" src="contacts icon.png">

                    </a>

                </td>

                <td style="padding-left: 0.521vw;">

                    <a style="" href>

                        <p id="socials">
                            Новини
                        </p>
                        <img id="socialsIcon" style="height: 2.083vw;display: none;padding-right: 2.604vw;;" src="socials icon.png">

                    </a>

                </td> 

            </tr>
        </table>


  

    </nav>
    </div>  
</head>
<body style="background-color: rgb(236, 224, 209);">

<div style="padding-top: 150px;">

</div>

<div style="margin: auto; background-color: rgb(55, 134, 224); width: 78.125vw; height: 1100px; background: rgb(149,195,246); background: linear-gradient(90deg, rgba(149,195,246,1) 0%, rgba(115,176,245,1) 50%, rgba(82,132,215,1) 100%);">
    <div style="padding-top: 100px;">
    </div>

    <h2>Добавяне на събитие</h2>
    <form action="save_event.php" method="POST">
        <label for="name">Име на събитието:</label>
        <input type="text" id="name" name="name" required><br><br>

        <label for="description">Описание:</label>
        <textarea id="description" name="description" required></textarea><br><br>

        <label for="event_date">Дата:</label>
        <input type="date" id="event_date" name="event_date" required><br><br>

        <label for="event_time">Час:</label>
        <input type="time" id="event_time" name="event_time" required><br><br>

        <input type="submit" value="Добави събитие">
    </form>

    <h2>Съществуващи събития</h2>

    <?php
    
    include 'config.php';

    
    $sql = "SELECT * FROM events";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
     
        echo "<table cellspacing='0' style='margin: auto;'>
                <tr>
                    <th>Име</th>
                    <th>Описание</th>
                    <th>Дата</th>
                    <th>Час</th>
                </tr>";

        while($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>" . $row["name"]. "</td>
                    <td>" . $row["description"]. "</td>
                    <td>" . $row["event_date"]. "</td>
                    <td>" . $row["event_time"]. "</td>
                </tr>";
        }
        echo "</table>";
    } else {
        echo "Няма събития.";
    }

    $conn->close();
    ?>

</div>

<footer>
    <table>
        <tr>
            <td>
                <img style="height: 100px;" src="Учи лесно (8).png">
            </td>
            <td>
                <h1 style="font-size: 60px;padding-left: 20px;">Учи лесно</h1>
            </td>
        </tr>
    </table>
    <hr>
    <br>
    <table>
        <tr style="align-items: flex-start;display: flex;">
            <td>
                <ul>
                    <li><p style="font-size: 25px;font-weight: 700;">За нас</p></li>
                    <li><p>Учи лесно™️</p></li>
                    <li><p>Отборът ни</p></li>
                    <li><p>Правила и условия</p></li>
                </ul>
            </td>
            <td>
                <ul>
                    <li><p style="font-size: 25px;font-weight: 700;">Свържете се</p></li>
                    <li><p><img src="socials icon.png"></p></li>
                    <li><p><img src="aaa.png"></p></li>
                    <li><p><img src="X_logo_2023_(white).png"></p></li>
                </ul>
            </td>
            <td>
                <ul>
                    <li><p style="font-size: 25px;font-weight: 700;">Навигация</p></li>
                    <li><p><a href="">Начало</a></p></li>
                </ul>
            </td>
        </tr>
    </table>
    <br>
    <hr>
</footer>
</body>
</html>
