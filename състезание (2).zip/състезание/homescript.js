window.onscroll = function() {navScrollFunction()};
        
function navScrollFunction() {
  if (document.body.scrollTop > 30 || document.documentElement.scrollTop > 30) {

    document.getElementById("logo").style.top="-0.469vw";
    document.getElementById("logo").style.height="3.125vw";
    document.getElementById("logo").src="Учи лесно (8).png";

    document.getElementById("nav").style.height="3.125vw";
    

    document.getElementById("menuicon").style.top="-0.26vw"; 

    document.getElementById("menu-content").style.top="-0px";

    document.getElementById("links").style.top="-0.469vw";  
    
  } else {

    document.getElementById("logo").style.top="-15px";
    document.getElementById("logo").style.height="6.771vw";
    document.getElementById("logo").src="Учи лесно (11).png";

    document.getElementById("nav").style.height = "5.208vw";

    document.getElementById("links").style.top="0px";  

    document.getElementById("menuicon").style.top="0"; 

    document.getElementById("menu-content").style.top="2.083vw";


    
  }
}

document.addEventListener('DOMContentLoaded', function() {
    let goldPassActivated = true;

  function updateGoldPassAppearance() {
      document.querySelectorAll('#goldPass td').forEach(td => {
        if (goldPassActivated) {
          
  function toggleGoldPass() {
    goldPassActivated = !goldPassActivated;
    updateGoldPassAppearance();
}
function darkenTdsByTier() {
  // Get all td elements on the page
  const tds = document.querySelectorAll('td');
  
  tds.forEach(td => {
      
      // Match both "GTierX" and "TierX"
      const match = td.id.match(/^(GTier)(\d+)$/);

      if (match) {
          const tierNumber = parseInt(match[2]); // Extract the tier number

          // ✅ Recognize "GTier0" but keep it fully white (no darkness applied)
          if (tierNumber === 0) {
            td.style.boxShadow = `inset 0 0 0 1000px rgba(0, 0, 0, 0)`;
              return;
          }

          // Apply nonlinear scaling for darkness
          const darknessLevel = Math.pow(Math.min(tierNumber / 100, 1), 1/2);                
          td.style.boxShadow = `inset 0 0 0 1000px rgba(31, 14, 2, ${darknessLevel})`;
            td.style.borderColor = `rgba(0, 0, 0, ${darknessLevel+3/10})`;
          td.style.bacColor = `rgba(0, 0, 0, ${darknessLevel})`;
      }
  });
}

// Call the function once the DOM has fully loaded
darkenTdsByTier();


      }
       else {

          
  function toggleGoldPass() {
    goldPassActivated = !goldPassActivated;
    updateGoldPassAppearance();
}

function darkenTdsByTier() {
  // Get all td elements on the page
  const tds = document.querySelectorAll('td');
  
  tds.forEach(td => {
      //console.log(`Processing td with ID: ${td.id}`);  // Debugging: Log the td's ID
      
      // Match both "GTierX" and "TierX"
      const match = td.id.match(/^(GTier)(\d+)$/);

      if (match) {
          const tierNumber = parseInt(match[2]); // Extract the tier number

          // ✅ Recognize "GTier0" but keep it fully white (no darkness applied)
          if (tierNumber === 0) {
            td.style.boxShadow = `inset 0 0 0 1000px rgba(0, 0, 0, 0)`;
              return;
          }

          // Apply nonlinear scaling for darkness
          const darknessLevel = Math.pow(Math.min(tierNumber / 100, 1), 1/2);                
          td.style.boxShadow = `inset 0 0 0 1000px rgba(31, 14, 2, ${darknessLevel+1/2})`;
            td.style.borderColor = `rgba(0, 0, 0, ${0.5 + darknessLevel+2/10})`;
      }
  });
}

// Call the function once the DOM has fully loaded
darkenTdsByTier();


      }
      });
  }
  
  updateGoldPassAppearance();
  

  function darkenTdsByTier2() {
    // Get all td elements on the page
    const tds = document.querySelectorAll('td');
    
    tds.forEach(td => {
        
        // Match both "GTierX" and "TierX"
        const match = td.id.match(/^(STier)(\d+)$/);
  
        if (match) {
            const tierNumber = parseInt(match[2]); // Extract the tier number
  
            // ✅ Recognize "GTier0" but keep it fully white (no darkness applied)
            if (tierNumber === 0) {
              td.style.boxShadow = `inset 0 0 0 1000px rgba(0, 0, 0, 0)`;
                return;
            }
  
            // Apply nonlinear scaling for darkness
            const darknessLevel = Math.pow(Math.min(tierNumber / 100, 1), 1/2);                
            td.style.boxShadow = `inset 0 0 0 1000px rgba(2, 14, 31, ${darknessLevel})`;
            td.style.borderColor = `rgba(2, 12, 28, ${darknessLevel+2/10})`;
        }
    });
  }
  
  // Call the function once the DOM has fully loaded
  darkenTdsByTier2();


});

function extractDayAndYearFromDate(){
  const date = new Date();
  let dateString = date.toString();
  dateString = dateString.slice(8, 21);
  let day = dateString.slice(0, 2);
  let year = dateString.slice(3, 7);
  let i = 0;



  while (i < day.length && day[i] === '0') //Increments [i], whilst it's less than the length of [day] and is equal and the same type to 0
  {
    i++;
  }

  day = day.slice(i) || "0";

// Extract the substring starting from the first non-zero character
  day = parseInt(day); //Turns [day] into an integer
  year = parseInt(year); //Turns [year] into an integer
  //console.log(day);//debugging
  //console.log(year);//debugging

}
function extractMonthFromDate(){
  const date = new Date();
  let dateString = date.toString();
  let month = dateString.slice(4, 7);
  let monthnum;

  switch(month){
    case "Jan":
      monthnum = 1;
      break;
    case "Feb":
      monthnum = 2;
      break;
    case "Mar":
      monthnum = 3;
      break;
    case "Apr":
      monthnum = 4;
      break;
    case "May":
      monthnum = 5;
      break;
    case "Jun":
      monthnum = 6;
      break;
    case "Jul":
      monthnum = 7;
      break;
    case "Aug":
      monthnum = 8;
      break;
    case "Sep":
      monthnum = 9;
      break;
    case "Oct":
      monthnum = 10;
      break;
    case "Nov":
      monthnum = 11;
      break;
    case "Dec":
      monthnum = 12;
      break;
    
  }

  //console.log(monthnum); //debugging
}

extractDayAndYearFromDate();

extractMonthFromDate();

const date = new Date();
console.log(date);

let eventName;
let eventDate;
let eventDescription;
let eventTime;

const eventNames = [];
const eventDescriptions = [];
const eventDates = [];
const eventTimes = [];

const eventInfo = {};

let newRowIndex = 0;
const newRowIndexes = [];
window.onload = function() { 
    document.getElementById("submitBox").onclick = function() {

        // Get input values
        let eventName = document.getElementById("eventNameBox").value;
        let eventDescription = document.getElementById("eventDescriptionBox").value;
        let eventDate = document.getElementById("eventDateBox").value;
        let eventTime = document.getElementById("eventTimeBox").value;

        // Push values into arrays
        eventNames.push(eventName);
        eventDescriptions.push(eventDescription);
        eventDates.push(eventDate);
        eventTimes.push(eventTime);

        //console.log(eventNames, eventDescriptions, eventDates, eventTimes);

        // Store in eventInfo object
        eventInfo.name = eventName;
        eventInfo.description = eventDescription;
        eventInfo.date = eventDate;
        eventInfo.time = eventTime;

        //console.log(eventInfo); //debugging

        // Add data to table
        let table = document.getElementById("eventBook");
        let newRow = table.insertRow();

        newRowIndex += 1;
        newRowIndexes.push(newRowIndex);
        let newRowInfo = [eventName, eventDescription, eventDate, eventTime, newRowIndex]; 
        //console.log(newRowInfo); //debugging

        //console.log(newRowIndex);
        //console.log(newRowIndexes);
        
        newRow.classList.add("styledEventBookTrTd");

        let nameCell = newRow.insertCell(0);
        let descCell = newRow.insertCell(1);
        let dateCell = newRow.insertCell(2);
        let timeCell = newRow.insertCell(3);
        let iconCell = newRow.insertCell(4);

        let cells = [nameCell, descCell, dateCell, timeCell];
        cells.forEach(cell => {
            cell.classList.add("styledEventBookTrTd");
        });
      

        nameCell.innerHTML = eventName;
        descCell.innerHTML = eventDescription;
        dateCell.innerHTML = eventDate;
        timeCell.innerHTML = eventTime;
        iconCell.innerHTML = `<button id="deleteBox${newRowIndex}" style="border:none;" >  <img src="deleteRowIcon.png"> </button>` ;

        let rowId = document.getElementById(`deleteBox${newRowIndex}`);
        rowId = rowId.id;
        rowId = rowId.slice(9);

        rowId = parseInt(rowId)

        

        console.log(newRowIndex + ' rowIndex');
        console.log(rowId + ' rowId');

        // Clear input fields after submission
        setTimeout(function() {
            document.getElementById("eventNameBox").value = "";
            document.getElementById("eventDescriptionBox").value = "";
            document.getElementById("eventDateBox").value = "";
            document.getElementById("eventTimeBox").value = "";
        }, 0);
        document.getElementById(`deleteBox${newRowIndex}`).onclick = function() {
  let table = document.getElementById("eventBook"); // Get the table



  if (table.rows.length > 2) {// Check if there's at least one row to delete
      rowId -= 1;   

      table.deleteRow(rowId);  // Deletes the last row

      console.log(newRowIndex + ' rowIndex');
      console.log(rowId + ' rowId');
      //console.log(newRowIndexes);

      return(rowId);

  }
  




};
};

    };





